﻿using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Servicios.Core.Entities;
using Servicios.Core.Interfaces;
using Servicios.Core.Services;
using System.Text.Json.Serialization;
using Servicios.Core.Dto;
using System.Dynamic;
using System.Collections.Generic;

namespace Servicios.Infrastructure.Repositories
{
    public class ConsultaPokemonRepository : IConsultaPokemonRepository
    {
        private readonly HttpClient _httpClient;

        public ConsultaPokemonRepository(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<AbilityInfo>> GetHiddenAbilitiesAsync(string pokemonName)
        {
            string url = $"https://pokeapi.co/api/v2/pokemon/{pokemonName}";
            HttpResponseMessage response = await _httpClient.GetAsync(url);

            if (response.IsSuccessStatusCode)
            {
                string responseBody = await response.Content.ReadAsStringAsync();

                ConsultaPokemonEntity pokemon = JsonSerializer.Deserialize<ConsultaPokemonEntity>(responseBody, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                List<AbilityInfo> abilities = new List<AbilityInfo>();
                foreach (var ability in pokemon.Abilities)
                {
                    abilities.Add(new AbilityInfo
                    {
                        AbilityDetails = new AbilityDetails
                        {
                            Name = ability.AbilityDetails.Name,
                            Url = ability.AbilityDetails.Url
                        },
                        IsHidden = ability.IsHidden,
                        Slot = ability.Slot
                    });
                }

                return abilities; // Retornar la lista de habilidades
            }

            return new List<AbilityInfo>(); // Retornar una lista vacía si la petición falla
        }

    }
}

