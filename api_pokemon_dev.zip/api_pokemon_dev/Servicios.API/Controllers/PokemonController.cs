﻿using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Servicios.Core.Interfaces;
using Servicios.Core.Services;
using Servicios.Core.Dto;

namespace Servicios.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PokemonController : ControllerBase
    {
        private readonly IConsultaPokemonService _consultaPokemonService;

        public PokemonController(IConsultaPokemonService ConsultaPokemonService)
        {
            _consultaPokemonService = ConsultaPokemonService;
        }

        [HttpGet("{pokemonName}")]
        public async Task<IActionResult> ObtenerHabilidadesOcultasAsync(string pokemonName)
        {
            if (string.IsNullOrWhiteSpace(pokemonName))
            {
                return BadRequest("El nombre del Pokémon no puede estar vacío.");
            }

            try
            {
                var result = await _consultaPokemonService.ObtenerHabilidadesOcultasAsync(pokemonName);

                if (result == null || result.Habilidades == null || result.Habilidades.Ocultas.Count == 0)
                {
                    return NotFound($"No se encontraron habilidades ocultas para el Pokémon {pokemonName}.");
                }

                return Ok(result);
            }
            catch (HttpRequestException)
            {
                return StatusCode(500, "Error al comunicarse con el servicio de Pokémon.");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Error interno del servidor: {ex.Message}");
            }
        }
    }
}
