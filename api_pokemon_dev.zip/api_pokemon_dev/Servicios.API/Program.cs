using Servicios.Core.Interfaces;
using Servicios.Core.Services;
using Servicios.Infrastructure.Repositories;

var builder = WebApplication.CreateBuilder(args);

// Agregar servicios al contenedor.
builder.Services.AddControllers();
builder.Services.AddScoped<IConsultaPokemonService, ConsultaPokemonService>();
builder.Services.AddScoped<IConsultaPokemonRepository, ConsultaPokemonRepository>();

// Configurar HttpClient para IConsultaPokemonRepository
builder.Services.AddHttpClient<IConsultaPokemonRepository, ConsultaPokemonRepository>();

// Configuraci�n de Swagger/OpenAPI
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configurar el pipeline de solicitudes HTTP.
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseSwagger();
    app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1"));
}
else
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();
app.MapControllers();

app.Run();