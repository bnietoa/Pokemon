﻿using Servicios.Core.Dto;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Servicios.Core.Entities
{
    public class ConsultaPokemonEntity
    {
        [JsonPropertyName("abilities")]
        public List<Ability> Abilities { get; set; }
    }
}

