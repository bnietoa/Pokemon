﻿using Servicios.Core.Dto;
using Servicios.Core.Entities;
using System.Threading.Tasks;

namespace Servicios.Core.Interfaces
{
    public interface IConsultaPokemonRepository
    {
        Task<List<AbilityInfo>> GetHiddenAbilitiesAsync(string pokemonName);
    }
}