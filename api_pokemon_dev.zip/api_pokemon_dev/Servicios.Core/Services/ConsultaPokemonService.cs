﻿using Servicios.Core.Interfaces;
using Servicios.Core.Services;
using System.Collections.Generic;
using System.Threading.Tasks;
using Servicios.Core.Dto;
using Servicios.Core.Entities;

namespace Servicios.Core.Services
{
    public class ConsultaPokemonService : IConsultaPokemonService
    {
        private readonly IConsultaPokemonRepository _consultaPokemonRepository;

        public ConsultaPokemonService(IConsultaPokemonRepository consultaPokemonRepository)
        {
            _consultaPokemonRepository = consultaPokemonRepository;
        }

        public async Task<PokemonHabilidadesResponse> ObtenerHabilidadesOcultasAsync(string pokemonName)
        {
            // Obtener las habilidades del Pokémon desde el repositorio
            var abilities = await _consultaPokemonRepository.GetHiddenAbilitiesAsync(pokemonName);

            if (abilities == null)
            {
                // Manejar el caso en el que no se encuentren habilidades o el Pokémon no exista
                return new PokemonHabilidadesResponse
                {
                    Habilidades = new Habilidades
                    {
                        Ocultas = new List<AbilityInfo>()
                    }
                };
            }

            // Filtrar habilidades ocultas
            // Filtrar habilidades ocultas
            var habilidadesOcultas = new List<AbilityInfo>();
            foreach (var ability in abilities)
            {
                if (ability?.AbilityDetails != null && ability.IsHidden)
                {
                    habilidadesOcultas.Add(new AbilityInfo
                    {
                        AbilityDetails = new AbilityDetails
                        {
                            Name = ability.AbilityDetails.Name,
                            Url = ability.AbilityDetails.Url
                        },
                        IsHidden = ability.IsHidden,
                        Slot = ability.Slot
                    });
                }
            }


            // Crear la respuesta con las habilidades ocultas
            return new PokemonHabilidadesResponse
            {
                Habilidades = new Habilidades
                {
                    Ocultas = habilidadesOcultas
                }
            };
        }
    }
}
