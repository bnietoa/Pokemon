﻿
using System.Text.Json.Serialization;

namespace Servicios.Core.Dto
{
    public class Ability
    {
        [JsonPropertyName("ability")]
        public AbilityDetails AbilityDetails { get; set; }

        [JsonPropertyName("is_hidden")]
        public bool IsHidden { get; set; }

        public int Slot { get; set; }
    }

    public class AbilityDetails
    {
        public string Name { get; set; }
        public string Url { get; set; }


    }

    public class AbilityInfo
    {
        public AbilityDetails AbilityDetails { get; set; }
        public bool IsHidden { get; set; }
        public int Slot { get; set; }


    }
}
