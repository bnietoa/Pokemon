﻿
using Servicios.Core.Dto;

namespace Servicios.Core.Entities
{
    public class PokemonHabilidadesResponse
    {
        public Habilidades Habilidades { get; set; }

    }   
        

    public class Habilidades
    {
        public List<AbilityInfo> Ocultas { get; set; }
        //public List<Ability> Ocultas { get; set; }
        
    }
}
